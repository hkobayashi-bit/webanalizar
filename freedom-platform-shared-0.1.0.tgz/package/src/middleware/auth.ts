import { defineEventHandler, getRequestHeader } from 'h3'
import type { AuthContext } from '../types'

/**
 * Nuxt server middleware that extracts user info from oauth2-proxy headers.
 * oauth2-proxy sets X-User and X-Email headers for authenticated requests.
 */
export default defineEventHandler((event) => {
  const email = getRequestHeader(event, 'x-email') || ''
  const user = getRequestHeader(event, 'x-user') || ''

  const auth: AuthContext = { email, user }
  event.context.auth = auth
})
