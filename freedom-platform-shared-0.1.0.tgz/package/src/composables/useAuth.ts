import type { AuthContext } from '../types'

/**
 * Client-side composable that fetches the current user's auth info from /api/me.
 * Each app must have the /api/me endpoint (use the shared server/api/me.get.ts).
 */
export const useAuth = () => {
  const { data } = useFetch<AuthContext>('/api/me')

  return {
    email: computed(() => data.value?.email || ''),
    user: computed(() => data.value?.user || ''),
    isAuthenticated: computed(() => !!data.value?.email),
  }
}
