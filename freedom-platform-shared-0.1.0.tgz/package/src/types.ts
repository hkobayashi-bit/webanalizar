export interface AuthContext {
  email: string
  user: string
}

declare module 'h3' {
  interface H3EventContext {
    auth: AuthContext
  }
}
