import { defineEventHandler } from 'h3'

/**
 * API endpoint that returns the current user's auth info.
 * Relies on the auth middleware having set event.context.auth.
 */
export default defineEventHandler((event) => {
  return event.context.auth || { email: '', user: '' }
})
